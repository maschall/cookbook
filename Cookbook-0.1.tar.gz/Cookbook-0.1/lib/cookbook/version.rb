module Cookbook
  VERSION = '0.1'
end